export const loading = (data) => {
    return {
        type: 'LOADING',
        payload : data
    };
};