import React from 'react'

function LatestProduct() {
    return (
        <div>
            Latest Product
        </div>
    )
}

export default LatestProduct
