import React from 'react'

function TermsComponent() {
    return (
        <div>
            Terms Page.
        </div>
    )
}

export default TermsComponent
