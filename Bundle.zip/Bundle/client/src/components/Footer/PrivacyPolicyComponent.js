import React from 'react'

function PrivacyPolicyComponent() {
    return (
        <div>
            Privacy Page.
        </div>
    )
}

export default PrivacyPolicyComponent
