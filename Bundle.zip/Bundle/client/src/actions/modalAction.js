export const modal = (data) =>{
    return {
        type: 'MODAL',
        payload : data
    }
}