export const cartQuantity = (data) => {
    return {
        type: 'CART_QUANTITY',
        payload: data
    };
};