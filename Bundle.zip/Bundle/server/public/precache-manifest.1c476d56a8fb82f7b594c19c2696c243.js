self.__precacheManifest = (self.__precacheManifest || []).concat([
  {
    "revision": "c9c3a8d0ab8a64ab9b3b9908d7de08a4",
    "url": "/index.html"
  },
  {
    "revision": "7102f3f276af68fac5c0",
    "url": "/static/css/2.d370cae6.chunk.css"
  },
  {
    "revision": "8a3c5a796b3ad5ceec99",
    "url": "/static/css/main.abe55023.chunk.css"
  },
  {
    "revision": "7102f3f276af68fac5c0",
    "url": "/static/js/2.283793d6.chunk.js"
  },
  {
    "revision": "4c612ed0f24f0ebbdfaff4655f3d99df",
    "url": "/static/js/2.283793d6.chunk.js.LICENSE.txt"
  },
  {
    "revision": "8a3c5a796b3ad5ceec99",
    "url": "/static/js/main.ec8463aa.chunk.js"
  },
  {
    "revision": "73635f645c271e35ff15",
    "url": "/static/js/runtime-main.83c3e0c4.js"
  },
  {
    "revision": "3962801b8188558745c0072a85065218",
    "url": "/static/media/Main-Banner1.3962801b.jpg"
  },
  {
    "revision": "743784f7c104086ed8c49b3eb4fa7119",
    "url": "/static/media/Main-Banner2.743784f7.jpg"
  },
  {
    "revision": "d1bd938d31e990a42605559c6a905f6c",
    "url": "/static/media/Main-Banner3.d1bd938d.jpg"
  },
  {
    "revision": "26748af041e321d5cc46ecc5518d95e0",
    "url": "/static/media/brand-logo.26748af0.png"
  },
  {
    "revision": "482e1496854e861b77d55373e739910a",
    "url": "/static/media/product1.482e1496.jpg"
  },
  {
    "revision": "04eb8fc57f27498e5ae37523e3bfb2c7",
    "url": "/static/media/revicons.04eb8fc5.woff"
  },
  {
    "revision": "17629a5dfe0d3c3946cf401e1895f091",
    "url": "/static/media/revicons.17629a5d.ttf"
  },
  {
    "revision": "2feb69ccb596730c72920c6ba3e37ef8",
    "url": "/static/media/revicons.2feb69cc.eot"
  },
  {
    "revision": "4474be7c768fba4f2d2f28bf1cf8f7a0",
    "url": "/static/media/temperature.4474be7c.svg"
  },
  {
    "revision": "a0367c9645e35be80bf77a4a4c40efb7",
    "url": "/static/media/whatsapp.a0367c96.svg"
  },
  {
    "revision": "ae74b7967fe2e857d26271f109ea6d90",
    "url": "/static/media/wind.ae74b796.svg"
  }
]);