self.__precacheManifest = (self.__precacheManifest || []).concat([
  {
    "revision": "701262c418a9db36de50051b3a929b5f",
    "url": "/admin/index.html"
  },
  {
    "revision": "74d75edd7ff63dce1cd7",
    "url": "/admin/static/css/2.e3cf4cf6.chunk.css"
  },
  {
    "revision": "76e760d1db3d57b96622",
    "url": "/admin/static/css/main.706a94ac.chunk.css"
  },
  {
    "revision": "74d75edd7ff63dce1cd7",
    "url": "/admin/static/js/2.0bcb399f.chunk.js"
  },
  {
    "revision": "4ea52ce9d0fe006065ead9b654d1dca1",
    "url": "/admin/static/js/2.0bcb399f.chunk.js.LICENSE.txt"
  },
  {
    "revision": "76e760d1db3d57b96622",
    "url": "/admin/static/js/main.12e6ad1d.chunk.js"
  },
  {
    "revision": "c22fafc82780b51e4136",
    "url": "/admin/static/js/runtime-main.725b2414.js"
  },
  {
    "revision": "26748af041e321d5cc46ecc5518d95e0",
    "url": "/admin/static/media/brand-logo.26748af0.png"
  },
  {
    "revision": "e6dcd1813a9912ee968c9ff5237fb936",
    "url": "/admin/static/media/loader.e6dcd181.gif"
  },
  {
    "revision": "b4668cd814982b6ce2777454e2b56980",
    "url": "/admin/static/media/loginBg.b4668cd8.jpg"
  }
]);