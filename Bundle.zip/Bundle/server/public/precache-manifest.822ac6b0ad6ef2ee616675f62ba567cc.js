self.__precacheManifest = (self.__precacheManifest || []).concat([
  {
    "revision": "32225ee58c899dad6499e86e1cf840c9",
    "url": "/admin/index.html"
  },
  {
    "revision": "f2e006b92bcbbcf35bcc",
    "url": "/admin/static/css/2.e3cf4cf6.chunk.css"
  },
  {
    "revision": "d773337f055f3bed3684",
    "url": "/admin/static/css/main.07218aba.chunk.css"
  },
  {
    "revision": "f2e006b92bcbbcf35bcc",
    "url": "/admin/static/js/2.f4afaf0e.chunk.js"
  },
  {
    "revision": "8ad31cd7921ecba44759aa02c105093b",
    "url": "/admin/static/js/2.f4afaf0e.chunk.js.LICENSE.txt"
  },
  {
    "revision": "d773337f055f3bed3684",
    "url": "/admin/static/js/main.d967241f.chunk.js"
  },
  {
    "revision": "c22fafc82780b51e4136",
    "url": "/admin/static/js/runtime-main.725b2414.js"
  },
  {
    "revision": "4b2ae729916298055850f817b5ff24ab",
    "url": "/admin/static/media/brand-logo.4b2ae729.png"
  },
  {
    "revision": "e6dcd1813a9912ee968c9ff5237fb936",
    "url": "/admin/static/media/loader.e6dcd181.gif"
  },
  {
    "revision": "b4668cd814982b6ce2777454e2b56980",
    "url": "/admin/static/media/loginBg.b4668cd8.jpg"
  }
]);